from setuptools import setup,find_packages

setup(
    name='Biblio2048',
    version='0.1.0',
    packages=[''],
    url='https://github.com/JeongHan-Bae/2048Bae',
    license='MIT',
    author='JeongHan-Bae',
    author_email='mastropseudo@gmail.com',
    description='bibliothèque de 2048'
)
